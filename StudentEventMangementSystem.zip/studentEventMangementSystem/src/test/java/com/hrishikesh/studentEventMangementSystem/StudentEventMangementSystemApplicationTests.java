package com.hrishikesh.studentEventMangementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentEventMangementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
